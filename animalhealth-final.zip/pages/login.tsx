import { useState } from 'react';
import { useRouter } from 'next/router';

export default function LoginPage() {
  const router = useRouter();
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');

  const handleLogin = async (e) => {
    e.preventDefault();
    setError('');
    if (email === 'manuel@teuscher.uk' && password === 'admin123') {
      router.push('/admin');
    } else {
      setError('Login fehlgeschlagen – bitte prüfen Sie Ihre Zugangsdaten.');
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-blue-50">
      <form onSubmit={handleLogin} className="bg-white p-8 rounded shadow-md w-full max-w-md">
        <h1 className="text-2xl font-bold mb-4 text-center">Anmeldung</h1>
        <label className="block mb-2">E-Mail-Adresse</label>
        <input type="email" value={email} onChange={(e) => setEmail(e.target.value)} required className="w-full px-3 py-2 border rounded mb-4" />
        <label className="block mb-2">Passwort</label>
        <input type="password" value={password} onChange={(e) => setPassword(e.target.value)} required className="w-full px-3 py-2 border rounded mb-4" />
        {error && <p className="text-red-600 text-sm mb-4">{error}</p>}
        <button type="submit" className="w-full bg-blue-700 text-white py-2 rounded hover:bg-blue-800">Anmelden</button>
      </form>
    </div>
  );
}