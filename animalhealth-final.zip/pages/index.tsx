import Head from 'next/head';
import Link from 'next/link';

export default function Home() {
  return (
    <div className="min-h-screen bg-white text-blue-900 px-6 py-10">
      <Head>
        <title>AnimalHealth – Startseite</title>
      </Head>
      <header className="flex justify-between items-center mb-10">
        <h1 className="text-3xl font-bold">AnimalHealth</h1>
        <Link href="/login">
          <button className="bg-blue-700 text-white px-4 py-2 rounded">Anmelden</button>
        </Link>
      </header>
      <section className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {agenten.map((agent, index) => (
          <Link key={index} href={`/agent/${agent.id}`}>
            <div className="p-4 border rounded shadow hover:shadow-xl cursor-pointer">
              <h2 className="font-semibold text-lg mb-2">{agent.title}</h2>
              <p className="text-sm text-blue-600">{agent.description}</p>
            </div>
          </Link>
        ))}
      </section>
    </div>
  );
}

const agenten = [
  { id: 'diagnostikos', title: 'Symptomanalyse', description: 'Diagnostikos' },
  { id: 'ethovet', title: 'Verhalten & Psyche', description: 'EthoVet' },
  { id: 'nutrivet', title: 'Ernährung', description: 'NutriVet' },
  { id: 'pharmvet', title: 'Medikamente prüfen', description: 'PharmVet' },
  { id: 'geovet', title: 'Notfallhilfe', description: 'GeoVet' },
  { id: 'visuvet', title: 'Bildanalyse', description: 'VisuVet' },
  { id: 'genovet', title: 'Genetik & Labor', description: 'GenoVet' },
  { id: 'epistovet', title: 'Brief erstellen', description: 'EpistoVet' },
  { id: 'profvet', title: 'Facharztanalyse', description: 'ProfVet' },
  { id: 'genesis', title: 'Agentengenerator', description: 'Genesis' },
  { id: 'validvet', title: 'Sicherheitsprüfung', description: 'ValidVet' },
];