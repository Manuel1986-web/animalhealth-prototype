import type { NextApiRequest, NextApiResponse } from 'next';
import { Configuration, OpenAIApi } from 'openai';

const config = new Configuration({
  apiKey: process.env.OPENAI_API_KEY,
});
const openai = new OpenAIApi(config);

export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  if (req.method !== 'POST') {
    return res.status(405).json({ message: 'Nur POST erlaubt' });
  }

  const { eingabe } = req.body;

  try {
    const gptResponse = await openai.createChatCompletion({
      model: 'gpt-4o',
      messages: [
        { role: 'system', content: 'Du bist ValidVet, ein tiermedizinischer Prüfagent. Prüfe die Eingabe auf logische Konsistenz, medizinische Sicherheit, Dosierungsrisiken oder toxische Aussagen. Gib eine kurze Bewertung mit Ampelfarbe und Empfehlung.' },
        { role: 'user', content: eingabe },
      ],
      max_tokens: 500,
    });

    const antwort = gptResponse.data.choices[0].message?.content;
    res.status(200).json({ validierung: antwort });
  } catch (error) {
    console.error('Fehler bei ValidVet:', error);
    res.status(500).json({ message: 'Interner Fehler bei ValidVet' });
  }
}